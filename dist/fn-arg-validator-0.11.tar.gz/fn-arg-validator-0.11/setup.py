from setuptools import setup


setup(
    name='fn-arg-validator',
    version='0.11',
    description="Provides a decorates which validates the arguments passed to a function",
    author="aash",
    author_email="aash.discover@gmail.com",
    py_modules=['validator'],
)
